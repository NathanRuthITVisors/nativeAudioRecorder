//>>built
define("dijit/form/nls/sk/validate",({invalidMessage:"Zadaná hodnota nie je platná.",missingMessage:"Táto hodnota je povinná.",rangeMessage:"Táto hodnota je mimo rozsah."}));
